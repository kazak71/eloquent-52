<?php

ini_set('display_errors', 'on');
header('Content-Type: application/json; charset=utf-8');
header('Content-Type: text/html; charset=utf-8');

require 'el/settings.php';

$brands = Models\Brand::all();

foreach ($brands as $brand) {
    echo $brand->id . ' ' . $brand->name;
    echo "<br>";
}

// $users = User::all();

// foreach ($users as $user) {
//     echo $user->firstname . ' ' . $user->lastname;
//     echo "<br>";
// }

// dd($users);
// $usr = $users->lists('firstname');
// echo $usr;
// echo $users->toJson(JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

echo "<hr>";

echo $former::horizontal_open();
echo $former::open_for_files();
echo $former::vertical_open_for_files();
echo $former::text('name')->label('My field');
echo $former::close();

    $page = isset($_REQUEST[$pageName]) ? $_REQUEST[$pageName] : null;

    // $results = Models\Brand::orderBy('id')->paginate($perPage, $columns, $pageName, $page)->setPath('index.php');
    $results = Models\Brand::orderBy('id')->paginate(3);
    ;

    echo '<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">';
    // echo '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">';
    echo '<h1>Users</h1>';
    echo '<table>';
foreach ($results as $brand) {
    echo "<tr><td>User number {$brand->name}</td></tr>";
}
    echo '<table>' . "\n";

    // echo $results->appends($_GET)->render();

    // echo $results->appends($_GET)->nextPageUrl();
    // echo $results->url($page);


    // dd($results);
    $presenter = new Illuminate\Pagination\Bootstrap4Presenter($results->appends($_GET));
    echo '<nav aria-label="Page navigation example"><ul class="pagination">';
    echo $presenter->render();
    echo '</ul></nav>';
