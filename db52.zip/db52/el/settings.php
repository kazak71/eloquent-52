<?php

// require_once __DIR__ . '/../../inc/connection.php';

$connection = [
    'driver' => 'mysql',
    'host' => '127.0.0.1',
    // 'database' => $db,
    'database' => 'ecomm-test',
    // 'username' => $db_user,
    'username' => 'root',
    // 'password' => $db_password,
    'password' => 'Alfa123#',
    'charset' => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix' => '',
];

require __DIR__ . '/vendor/autoload.php';
use Illuminate\Database\Capsule\Manager as DB;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator as Paginator;

Paginator::currentPathResolver(function () {
    return isset($_SERVER['REQUEST_URI']) ? strtok($_SERVER['REQUEST_URI'], '?') : '/';
});

// Set up a current page resolver
Paginator::currentPageResolver(function ($pageName = 'page') {
    $page = isset($_REQUEST[$pageName]) ? $_REQUEST[$pageName] : 1;
    return $page;
});

$perPage = 1; // results per page
$columns = ['*']; // (optional, defaults to *) array of columns to retrieve from database
$pageName = 'str'; // (optional, defaults to 'page') query string parameter name for the page number

// use Former\Facades\Former;

$former = new Former\Facades\Former;

$db = new DB;
$db->addConnection($connection);
$db->setAsGlobal();
$db->bootEloquent();
$db::connection()->enableQueryLog();

function jdump($data, $pretty = true)
{
    header('Content-Type: application/json; charset=utf-8');
    if (!$pretty === false) {
        echo $data->toJson(JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        echo $data;
    }
    exit;
}

function last_query()
{
    $queries = \Illuminate\Database\Capsule\Manager::getQueryLog();
    $last_query = end($queries);
    // return $last_query;
    $query = $last_query['query'];
    // dd($queries, $last_query);
    foreach ($last_query['bindings'] as $binding) {
        if (!is_numeric($binding)) {
            $binding = "'" . $binding . "'";
        }
        $query = preg_replace('/\?/', $binding, $query, 1);
    }
    return $query;
}
