<?php

/**
 * Created by Reliese Model.
 * Date: Fri, 15 Jun 2018 15:45:30 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Brand
 * 
 * @property int $id
 * @property string $name
 * @property bool $is_active
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 *
 * @package Models\Base
 */
class Brand extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'is_active' => 'bool'
	];
}
