<?php

namespace Models;

class Brand extends \Models\Base\Brand
{
	protected $fillable = [
		'name',
		'is_active'
	];
}
