<?php

namespace Models;

class InventoryLead extends \Models\Base\InventoryLead
{
	protected $fillable = [
		'id_inventory_main',
		'id_salesrep',
		'id_appointment',
		'quantity',
		'date_modified'
	];
}
