<?php

namespace Models;

class AssignedUser extends \Models\Base\AssignedUser
{
	protected $fillable = [
		'id_user',
		'period',
		'time_assign'
	];
}
