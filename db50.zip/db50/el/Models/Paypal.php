<?php

namespace Models;

class Paypal extends \Models\Base\Paypal
{
	protected $fillable = [
		'user_id',
		'ip',
		'paypal_array',
		'descr',
		'pay_month',
		'pay_sum',
		'updated_time',
		'to_arc'
	];
}
