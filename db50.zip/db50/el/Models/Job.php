<?php

namespace Models;

class Job extends \Models\Base\Job
{
	protected $fillable = [
		'id_lead',
		'number',
		'type',
		'id_salesrep',
		'id_booker',
		'created',
		'notes',
		'deleted',
		'id_app_sender',
		'completed'
	];
}
