<?php

namespace Models;

class Sale extends \Models\Base\Sale
{
	protected $fillable = [
		'id_lead',
		'product',
		'sales_date',
		'sales_notes',
		'id_app_sender'
	];
}
