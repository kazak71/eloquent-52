<?php

namespace Models;

class SoldInventory extends \Models\Base\SoldInventory
{
	protected $fillable = [
		'date_sold',
		'lead_id',
		'app_id',
		'id_model',
		'description',
		'serial_number',
		'quantity',
		'amount',
		'memo',
		'date_modified'
	];
}
