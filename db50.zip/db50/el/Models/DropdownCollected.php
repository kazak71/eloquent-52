<?php

namespace Models;

class DropdownCollected extends \Models\Base\DropdownCollected
{
	protected $fillable = [
		'collected',
		'disabled',
		'position'
	];
}
