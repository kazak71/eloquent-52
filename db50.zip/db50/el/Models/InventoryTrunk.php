<?php

namespace Models;

class InventoryTrunk extends \Models\Base\InventoryTrunk
{
	protected $fillable = [
		'id_inventory_main',
		'id_salesrep',
		'quantity',
		'date_modified'
	];
}
