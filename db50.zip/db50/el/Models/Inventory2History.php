<?php

namespace Models;

class Inventory2History extends \Models\Base\Inventory2History
{
	protected $fillable = [
		'serial_number',
		'id_model',
		'status',
		'id_user_modified',
		'id_appointment',
		'quantity',
		'date_modified'
	];
}
