<?php

namespace Models;

class SystemCellProvider extends \Models\Base\SystemCellProvider
{
	protected $fillable = [
		'descr',
		'prefix',
		'suffix',
		'provider'
	];
}
