<?php

namespace Models;

class ClockTime extends \Models\Base\ClockTime
{
	protected $fillable = [
		'clock_time',
		'clock_date',
		'cl_time',
		'cl_id',
		'username',
		'direction',
		'type_id',
		'user_id',
		'notes',
		'time_total'
	];
}
