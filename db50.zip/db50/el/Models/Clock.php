<?php

namespace Models;

class Clock extends \Models\Base\Clock
{
	protected $fillable = [
		'clock_time',
		'user_id',
		'username',
		'direction',
		'type_id',
		'notes'
	];
}
