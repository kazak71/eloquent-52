<?php

namespace Models;

class ClockType extends \Models\Base\ClockType
{
	protected $fillable = [
		'type_name',
		'in_out'
	];
}
