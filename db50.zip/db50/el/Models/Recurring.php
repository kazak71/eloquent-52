<?php

namespace Models;

class Recurring extends \Models\Base\Recurring
{
	protected $fillable = [
		'lead_id',
		'recurring_date'
	];
}
