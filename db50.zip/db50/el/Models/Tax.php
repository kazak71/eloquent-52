<?php

namespace Models;

class Tax extends \Models\Base\Tax
{
	protected $fillable = [
		'description',
		'tax_percent',
		'deleted',
		'date_delete'
	];
}
