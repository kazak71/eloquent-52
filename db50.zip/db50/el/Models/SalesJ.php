<?php

namespace Models;

class SalesJ extends \Models\Base\SalesJ
{
	protected $fillable = [
		'lead_id',
		'appointment_id',
		'sale_date',
		'serials',
		'price',
		'sales_rep',
		'sld_status',
		'date_modified',
		'id_user_modified',
		'finance_co',
		'amt_fin',
		'fin_pd',
		'cc_comp',
		'cc_pd',
		'chk_pd',
		'cash_pd',
		'gaamt',
		'comm',
		'cog',
		'overrd',
		'adcst',
		'taxable',
		'tax_rate',
		'install_date',
		'lead_source',
		'notes',
		'product_details',
		'package',
		'payment_details',
		'paid_on',
		'date_invoiced',
		'amt_invoiced',
		'invoice_pd'
	];
}
