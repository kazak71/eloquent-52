<?php

namespace Models;

class Waiver extends \Models\Base\Waiver
{
	protected $fillable = [
		'id_job',
		'id_agent',
		'name',
		'test_date',
		'customer_date',
		'water_pressure',
		'prv_recommended',
		'witness_date',
		'customer_signature',
		'witness_signature'
	];
}
