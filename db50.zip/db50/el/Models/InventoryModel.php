<?php

namespace Models;

class InventoryModel extends \Models\Base\InventoryModel
{
	protected $fillable = [
		'partno',
		'description',
		'material',
		'finish_color',
		'type',
		'deleted',
		'belong_to',
		'last_modified',
		'gift',
		'manifacturer',
		'purchase_price',
		'wholesale_price',
		'retail_price'
	];
}
