<?php

namespace Models;

class InventoryHistory extends \Models\Base\InventoryHistory
{
	protected $fillable = [
		'serial_number',
		'id_model',
		'status',
		'id_user_modified',
		'id_appointment',
		'quantity',
		'date_modified'
	];
}
