<?php

namespace Models;

class FinanceCo extends \Models\Base\FinanceCo
{
	protected $fillable = [
		'finance_co_name'
	];
}
