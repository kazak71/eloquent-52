<?php

namespace Models;

class Inventory2Main extends \Models\Base\Inventory2Main
{
	protected $fillable = [
		'serial_number',
		'id_manager_inserted',
		'id_model',
		'quantity',
		'deleted',
		'date_inserted',
		'date_modified'
	];
}
