<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:51 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemOffice
 * 
 * @property int $id_office
 * @property string $office_name
 * @property string $office_db
 * @property bool $to_arc
 *
 * @package Models\Base
 */
class SystemOffice extends Eloquent
{
	protected $primaryKey = 'id_office';
	public $timestamps = false;

	protected $casts = [
		'to_arc' => 'bool'
	];
}
