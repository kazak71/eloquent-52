<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:50 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class DropdownCollected
 * 
 * @property int $id
 * @property string $collected
 * @property bool $disabled
 * @property int $position
 *
 * @package Models\Base
 */
class DropdownCollected extends Eloquent
{
	protected $table = 'dropdown_collected';
	public $timestamps = false;

	protected $casts = [
		'disabled' => 'bool',
		'position' => 'int'
	];
}
