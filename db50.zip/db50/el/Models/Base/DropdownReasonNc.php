<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:50 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class DropdownReasonNc
 * 
 * @property int $id
 * @property string $reason_for_nc
 * @property bool $disabled
 * @property int $position
 *
 * @package Models\Base
 */
class DropdownReasonNc extends Eloquent
{
	protected $table = 'dropdown_reason_nc';
	public $timestamps = false;

	protected $casts = [
		'disabled' => 'bool',
		'position' => 'int'
	];
}
