<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:50 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Geolocation
 * 
 * @property string $username
 * @property string $lat
 * @property string $lon
 * @property \Carbon\Carbon $loctime
 *
 * @package Models\Base
 */
class Geolocation extends Eloquent
{
	protected $table = 'geolocation';
	protected $primaryKey = 'username';
	public $incrementing = false;
	public $timestamps = false;

	protected $dates = [
		'loctime'
	];
}
