<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:50 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class DropdownBillTo
 * 
 * @property int $id
 * @property string $bill_to
 * @property bool $disabled
 *
 * @package Models\Base
 */
class DropdownBillTo extends Eloquent
{
	protected $table = 'dropdown_bill_to';
	public $timestamps = false;

	protected $casts = [
		'disabled' => 'bool'
	];
}
