<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:51 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class SystemUser
 * 
 * @property int $id
 * @property string $username
 * @property string $pass
 * @property string $type
 * @property string $subtype
 * @property string $fname
 * @property string $lname
 * @property int $id_provider
 * @property string $tel_cell
 * @property string $tel_home
 * @property string $fax
 * @property string $city
 * @property string $post_code
 * @property string $addr1
 * @property string $addr2
 * @property bool $deleted
 * @property \Carbon\Carbon $date_delete
 * @property \Carbon\Carbon $date_add
 * @property bool $inactive
 * @property string $email
 *
 * @package Models\Base
 */
class SystemUser extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_provider' => 'int',
		'deleted' => 'bool',
		'inactive' => 'bool'
	];

	protected $dates = [
		'date_delete',
		'date_add'
	];
}
