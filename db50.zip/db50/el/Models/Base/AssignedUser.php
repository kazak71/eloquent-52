<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:50 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class AssignedUser
 * 
 * @property int $id
 * @property int $id_user
 * @property \Carbon\Carbon $period
 * @property \Carbon\Carbon $time_assign
 *
 * @package Models\Base
 */
class AssignedUser extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'id_user' => 'int'
	];

	protected $dates = [
		'period',
		'time_assign'
	];
}
