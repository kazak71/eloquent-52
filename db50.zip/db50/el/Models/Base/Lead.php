<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:50 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Lead
 * 
 * @property int $id
 * @property int $lead_num
 * @property string $name
 * @property string $name_spouse
 * @property string $address
 * @property int $number
 * @property string $suite
 * @property string $city
 * @property string $state
 * @property string $zip
 * @property string $postal_code_prefix
 * @property string $phone
 * @property string $phone_orig
 * @property int $id_set
 * @property int $block
 * @property int $id_quadr
 * @property int $id_quadr_flyer
 * @property string $status
 * @property int $na_level
 * @property string $survey_mr_mrs
 * @property string $booker_mr_mrs
 * @property string $family_status
 * @property string $age
 * @property string $age_spouse
 * @property string $allergy_problems
 * @property string $allergy_type
 * @property string $allergy_at_work
 * @property string $cleaning_system
 * @property string $vacuum_age_yrs
 * @property string $own_home
 * @property string $air_pollution
 * @property string $smokers
 * @property string $pets
 * @property string $laundry_detergent
 * @property string $credit_card
 * @property string $employment
 * @property string $employment_spouse
 * @property string $occupation
 * @property string $occupation_spouse
 * @property string $work_period
 * @property string $work_period_spouse
 * @property string $car_year
 * @property string $home_constr
 * @property string $recycle_home
 * @property string $recycle_work
 * @property string $recycle_appliances
 * @property string $use_solar_energy
 * @property string $pet_name
 * @property string $high_school
 * @property string $hobby
 * @property string $mind_contact_again
 * @property string $contact_again
 * @property \Carbon\Carbon $date_survey
 * @property int $id_user_survey
 * @property string $book_status
 * @property int $id_booker
 * @property \Carbon\Carbon $booker_lastcall
 * @property \Carbon\Carbon $recall_date
 * @property int $id_booker_recall
 * @property int $ni_level_book
 * @property int $nh_level_book
 * @property string $notes
 * @property \Carbon\Carbon $notes_created_at
 * @property int $notes_id_agent
 * @property string $lead_type
 * @property string $lead_subtype
 * @property int $contact_counter
 * @property \Carbon\Carbon $upload_date
 * @property string $use_energy_star
 * @property string $use_heat
 * @property string $own_years
 * @property string $air_type
 * @property string $num_of_people
 * @property string $furn_efficiency
 * @property string $vehicles_use
 * @property string $vehicles_yrs
 * @property string $comm_to_work
 * @property string $work_in
 * @property string $retired_age
 * @property string $ret_work_field
 * @property string $comm_to_work_m
 * @property string $work_in_m
 * @property string $ret_work_field_m
 * @property string $gas_interested
 * @property int $transferred_to_crm
 * @property \Carbon\Carbon $reset_date
 * @property string $email
 * @property string $email_2
 * @property string $phone_2
 * @property string $cell
 * @property string $cell_2
 * @property string $Buyer1_fname
 * @property string $Buyer1_lname
 * @property string $Buyer2_fname
 * @property string $Buyer2_lname
 * @property string $buyer1_work
 * @property string $buyer2_work
 * @property string $buyer1_work_phone
 * @property string $buyer2_work_phone
 * @property \Carbon\Carbon $app_date
 * @property int $app_id
 * @property string $dealer
 * @property string $system
 * @property int $system_id_lead
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property \Carbon\Carbon $called_at
 * @property \Carbon\Carbon $vm_left
 * @property string $default_phone
 * @property string $call_history
 * @property int $id_user_call
 * @property int $num_of_calls
 * @property string $call_status
 * @property string $call_back_in
 * @property \Carbon\Carbon $call_back_on
 * @property int $recurring_number
 * @property \Carbon\Carbon $recurring_start
 * @property \Carbon\Carbon $sales_date
 * @property bool $is_booked
 * @property bool $no_service
 * @property string $quickbooks_id
 *
 * @package Models\Base
 */
class Lead extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'lead_num' => 'int',
		'number' => 'int',
		'id_set' => 'int',
		'block' => 'int',
		'id_quadr' => 'int',
		'id_quadr_flyer' => 'int',
		'na_level' => 'int',
		'id_user_survey' => 'int',
		'id_booker' => 'int',
		'id_booker_recall' => 'int',
		'ni_level_book' => 'int',
		'nh_level_book' => 'int',
		'notes_id_agent' => 'int',
		'contact_counter' => 'int',
		'transferred_to_crm' => 'int',
		'app_id' => 'int',
		'system_id_lead' => 'int',
		'id_user_call' => 'int',
		'num_of_calls' => 'int',
		'recurring_number' => 'int',
		'is_booked' => 'bool',
		'no_service' => 'bool'
	];

	protected $dates = [
		'date_survey',
		'booker_lastcall',
		'recall_date',
		'notes_created_at',
		'upload_date',
		'reset_date',
		'app_date',
		'called_at',
		'vm_left',
		'call_back_on',
		'recurring_start',
		'sales_date'
	];
}
