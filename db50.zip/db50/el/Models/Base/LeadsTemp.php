<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:50 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class LeadsTemp
 * 
 * @property int $id
 * @property string $n
 * @property string $Date
 * @property string $Name
 * @property string $Street
 * @property string $City
 * @property string $Province
 * @property string $Postal_code
 * @property string $Phone
 * @property string $Phone2
 * @property string $Memo
 * @property string $Item
 * @property string $Qty
 * @property string $Amount
 * @property string $product
 * @property string $sales_detail
 * @property string $email
 *
 * @package Models\Base
 */
class LeadsTemp extends Eloquent
{
	protected $table = 'leads_temp';
	public $timestamps = false;
}
