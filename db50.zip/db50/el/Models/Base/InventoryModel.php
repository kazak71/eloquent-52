<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:50 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class InventoryModel
 * 
 * @property int $id
 * @property string $partno
 * @property string $description
 * @property string $material
 * @property string $finish_color
 * @property int $type
 * @property int $deleted
 * @property string $belong_to
 * @property int $last_modified
 * @property int $gift
 * @property string $manifacturer
 * @property float $purchase_price
 * @property float $wholesale_price
 * @property float $retail_price
 *
 * @package Models\Base
 */
class InventoryModel extends Eloquent
{
	public $timestamps = false;

	protected $casts = [
		'type' => 'int',
		'deleted' => 'int',
		'last_modified' => 'int',
		'gift' => 'int',
		'purchase_price' => 'float',
		'wholesale_price' => 'float',
		'retail_price' => 'float'
	];
}
