<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:50 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class Inventory2History
 * 
 * @property int $id_history
 * @property string $serial_number
 * @property int $id_model
 * @property string $status
 * @property int $id_user_modified
 * @property int $id_appointment
 * @property int $quantity
 * @property \Carbon\Carbon $date_modified
 *
 * @package Models\Base
 */
class Inventory2History extends Eloquent
{
	protected $table = 'inventory2_history';
	protected $primaryKey = 'id_history';
	public $timestamps = false;

	protected $casts = [
		'id_model' => 'int',
		'id_user_modified' => 'int',
		'id_appointment' => 'int',
		'quantity' => 'int'
	];

	protected $dates = [
		'date_modified'
	];
}
