<?php

/**
 * Created by Reliese Model.
 * Date: Sat, 16 Jun 2018 13:38:50 +0000.
 */

namespace Models\Base;

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Class ClockType
 * 
 * @property int $type_id
 * @property string $type_name
 * @property int $in_out
 *
 * @package Models\Base
 */
class ClockType extends Eloquent
{
	protected $primaryKey = 'type_id';
	public $timestamps = false;

	protected $casts = [
		'in_out' => 'int'
	];
}
