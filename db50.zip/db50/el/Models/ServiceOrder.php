<?php

namespace Models;

class ServiceOrder extends \Models\Base\ServiceOrder
{
	protected $fillable = [
		'id_job',
		'id_salesrep',
		'id_agent',
		'name',
		'address',
		'city',
		'phone',
		'phone_2',
		'cell',
		'order_taken_date',
		'order_taken_time',
		'date_serviced',
		'arrival',
		'departure',
		'others',
		'parts',
		'signature'
	];
}
