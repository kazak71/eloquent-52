<?php

namespace Models;

class NotesTemp extends \Models\Base\NotesTemp
{
	protected $fillable = [
		'phone',
		'note'
	];
}
