<?php

namespace Models;

class Inventory2Model extends \Models\Base\Inventory2Model
{
	protected $fillable = [
		'partno',
		'description',
		'material',
		'finish_color',
		'type',
		'deleted',
		'belong_to',
		'last_modified',
		'tbd_view',
		'gift',
		'price'
	];
}
