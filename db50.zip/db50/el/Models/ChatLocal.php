<?php

namespace Models;

class ChatLocal extends \Models\Base\ChatLocal
{
	protected $fillable = [
		'id_sender',
		'id_receiver',
		'message',
		'date_sent',
		'readed'
	];
}
