<?php

namespace Models;

class TempNew extends \Models\Base\TempNew
{
	protected $fillable = [
		'lead_id',
		'type',
		'date',
		'item',
		'qty',
		'price',
		'amount'
	];
}
