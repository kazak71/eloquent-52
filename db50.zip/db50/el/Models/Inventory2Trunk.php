<?php

namespace Models;

class Inventory2Trunk extends \Models\Base\Inventory2Trunk
{
	protected $fillable = [
		'id_inventory_main',
		'id_user',
		'quantity',
		'date_modified'
	];
}
